﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.IO.Compression;
using System.Diagnostics;

namespace MinecraftSavior
{
    public partial class Main_Form : Form
    {
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern IntPtr AddFontMemResourceEx(IntPtr pbFont, uint cbFont,
            IntPtr pdv, [System.Runtime.InteropServices.In] ref uint pcFonts);

        private PrivateFontCollection fonts = new PrivateFontCollection();

        Font minecraftFont16;
        Font minecraftFont12;
        Font minecraftFont8;
        Font minecraftFont7;

        int NumFiles = 0;
        int proceced_files = 0;
        public Main_Form()
        {
            InitializeComponent();

            byte[] fontData = Properties.Resources.minecraft;
            IntPtr fontPtr = System.Runtime.InteropServices.Marshal.AllocCoTaskMem(fontData.Length);
            System.Runtime.InteropServices.Marshal.Copy(fontData, 0, fontPtr, fontData.Length);
            uint dummy = 0;
            fonts.AddMemoryFont(fontPtr, Properties.Resources.minecraft.Length);
            AddFontMemResourceEx(fontPtr, (uint)Properties.Resources.minecraft.Length, IntPtr.Zero, ref dummy);
            System.Runtime.InteropServices.Marshal.FreeCoTaskMem(fontPtr);

            minecraftFont16 = new Font(fonts.Families[0], 16.0F);
            minecraftFont12 = new Font(fonts.Families[0], 12.0F);
            minecraftFont8 = new Font(fonts.Families[0], 8.0F);
            minecraftFont7 = new Font(fonts.Families[0], 7.0F);
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private void Form1_Load(object sender, EventArgs e)
        {
            checkBox1.Font = minecraftFont12;
            checkBox2.Font = minecraftFont12;
            checkBox3.Font = minecraftFont12;
            checkBox4.Font = minecraftFont12;
            checkBox5.Font = minecraftFont12;
            checkBox6.Font = minecraftFont12;
            checkBox7.Font = minecraftFont12;
            checkBox8.Font = minecraftFont12;

            BT_Save.Font = minecraftFont16;
            BT_OpenMFolder.Font = minecraftFont7;

            label1.Font = minecraftFont12;
            LB_info.Font = minecraftFont8;
            LB_info.Text = "";

            //timer1.Start();

            try
            {
                string[] dirs = Directory.GetDirectories(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData));
                
                foreach (string dir in dirs)
                {
                    if (dir.Contains(".minecraft") && !dir.Contains(".minecraft_dungeons"))
                    {
                        //minecraft folder found!
                        LB_info.Text += "Folder ";

                        var fold = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

                        var dirName = $@"{fold}\.minecraft";

                        string[] folde = Directory.GetDirectories(dirName);

                        List<string> list = new List<string>();

                        foreach (string folder in folde) {
                            list.Add(Path.GetFileName(folder));
                        }

                        String[] direc = list.ToArray();

                        folde = direc;

                        if (folde.Contains("saves")){
                                
                        }
                        else
                        {
                            checkBox1.Enabled = false;
                        }

                        if (folde.Contains("screenshots")){
                                
                        }
                        else
                        {
                            checkBox2.Enabled = false;
                        }

                        if (folde.Contains("mods")){
                                
                        }
                        else
                        {
                            checkBox3.Enabled = false;
                        }
                            
                        if (folde.Contains("backups")){
                                
                        }
                        else
                        {
                            checkBox4.Enabled = false;
                        }

                        if (folde.Contains("resourcepacks")){
                                
                        }
                        else
                        {
                            checkBox5.Enabled = false;
                        }

                        if (folde.Contains("shaderpacks")){
                                
                        }
                        else
                        {
                            checkBox6.Enabled = false;
                        }

                        if (folde.Contains("versions")){
                                
                        }
                        else
                        {
                            checkBox7.Enabled = false;
                        }
                        if (checkBox1.Enabled == false) { LB_info.Text += " 'saves', "; }
                        if (checkBox2.Enabled == false) { LB_info.Text += " 'screenshots', "; }
                        if (checkBox3.Enabled == false) { LB_info.Text += " 'mods', "; }
                        if (checkBox4.Enabled == false) { LB_info.Text += " 'backups',"+ Environment.NewLine; }
                        if (checkBox5.Enabled == false) { LB_info.Text += " 'resourcepacks', "; }
                        if (checkBox6.Enabled == false) { LB_info.Text += " 'shaderpacks', "; }
                        if (checkBox7.Enabled == false) { LB_info.Text += " 'versions'," + Environment.NewLine; }
                        LB_info.Text += " not found.";
                        if(LB_info.Text == "Folder  not found.") { LB_info.Text = ""; }
                    }
                }
            }
            catch (Exception er)
            {
                MessageBox.Show("The process failed: " +  er.ToString());
            }
        }

        private void BT_reduce_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void BT_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
            }
        }

        private void checkBox1_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"This folder contains all the Singleplayer words. 
You wouldn't delete this, aren't you ?";
        }

        private void checkBox1_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = "";
        }

        private void checkBox2_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"This folder contains all screenshot you've
taken in minecraft, those are precious memories !";
        }

        private void checkBox2_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = "";
        }

        private void checkBox3_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"It contains mods you've installed on minecraft.";
        }

        private void checkBox3_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = "";
        }

        private void checkBox4_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"It contains all map backups, those are created
when you load a map with a different version.";
        }

        private void checkBox4_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            if (checkBox1.Checked)
            {
                Save_Saves();
            }
            if (checkBox2.Checked)
            {
                Save_Screenshots();
            }
            if (checkBox3.Checked)
            {
                Save_Mods();
            }
            if (checkBox4.Checked)
            {
                Save_Backups();
            }
            if (checkBox5.Checked)
            {
                Save_Resourcepacks();
            }
            if (checkBox6.Checked)
            {
                Save_Shaderpacks();
            }
            if (checkBox7.Checked)
            {
                Save_Versions();
            }
            BT_Save.Enabled = false;
        }
        private void Save_Saves()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\saves";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;

            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Saves.RunWorkerAsync();
        }
        private void Save_Screenshots()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\screenshots";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;

            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Screenshots.RunWorkerAsync();
        }

        private void Save_Mods()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\mods";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;

            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Mods.RunWorkerAsync();
        }

        private void Save_Backups()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\backups";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;

            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Backups.RunWorkerAsync();
        }

        private void Save_Resourcepacks()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\resourcepacks";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;
            
            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Resourcepacks.RunWorkerAsync();
        }

        private void Save_Shaderpacks()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\shaderpacks";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;

            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Shaderpacks.RunWorkerAsync();
        }

        private void Save_Versions()
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\versions";
            var count = System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories).Length;

            NumFiles += count;
            progressBar1.Maximum += count;
            progressBar1.Visible = true;
            BW_save_Versions.RunWorkerAsync();
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                progressBar1.Value = proceced_files;

                float percent = (float)(((double)progressBar1.Value / (double)progressBar1.Maximum) * 100);

                progressBar1.Refresh();
                progressBar1.CreateGraphics().DrawString(percent.ToString("0.00") + "%",minecraftFont8,Brushes.Black,
                    new PointF(progressBar1.Width / 2 - 10, progressBar1.Height / 2 - 8));


                if (progressBar1.Value == progressBar1.Maximum)
                {
                    if(progressBar1.Value != 0) { LB_info.Text = "Everything is saved !"; }
                    progressBar1.Visible = false;
                    progressBar1.Value = 0;
                    BT_Save.Enabled = true;
                    timer1.Stop();
                }
            }
            catch
            {

            }
        }
        private void BW_save_Saves_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\saves";

            var OutputFilename = Application.StartupPath + @"\saves.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {
                
                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "saves");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                        fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
        }

       

        private void BW_save_Screenshots_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\screenshots";

            var OutputFilename = Application.StartupPath + @"\screenshots.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {

                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "screenshots");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                        fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
        }

        private void BW_save_Mods_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\mods";

            var OutputFilename = Application.StartupPath + @"\mods.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {
                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "mods");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                    fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
            
        }

        private void BW_save_Backups_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\backups";

            var OutputFilename = Application.StartupPath + @"\backups.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {

                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "backups");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                        fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
        }

        private void BW_save_Resourcepacks_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\resourcepacks";

            var OutputFilename = Application.StartupPath + @"\resourcepacks.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {

                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "resourcepacks");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                        fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
        }

        private void BW_save_Shaderpacks_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\shaderpacks";

            var OutputFilename = Application.StartupPath + @"\shaderpacks.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {

                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "shaderpacks");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                        fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
        }

        private void BW_save_Versions_DoWork(object sender, DoWorkEventArgs e)
        {
            var folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var InputDirectory = $@"{folder}\.minecraft\versions";

            var OutputFilename = Application.StartupPath + @"\versions.zip";
            using (Stream zipStream = new FileStream(Path.GetFullPath(OutputFilename), FileMode.Create, FileAccess.Write))
            using (ZipArchive archive = new ZipArchive(zipStream, ZipArchiveMode.Create))
            {

                foreach (var filePath in System.IO.Directory.GetFiles(InputDirectory, "*.*", System.IO.SearchOption.AllDirectories))
                {
                    var relativePath = filePath.Replace(InputDirectory, "versions");
                    using (Stream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                    using (Stream fileStreamInZip = archive.CreateEntry(relativePath).Open())
                        fileStream.CopyTo(fileStreamInZip);
                    proceced_files += 1;
                }
            }
        }

        private void checkBox5_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"This folder contains all of your resourcepacks.";
        }

        private void checkBox5_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = @"";
        }

        private void checkBox6_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"This folder contains all of your shaderpacks,
if you have any.";
        }

        private void checkBox7_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"It contains all the version you've 
downloaded, the ones you select in the launcher.";
        }

        private void checkBox7_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = @"";
        }

        private void checkBox8_MouseHover(object sender, EventArgs e)
        {
            LB_info.Text = @"This will save all of Minecraft folder.
It may take a while to zip everything !";
        }

        private void checkBox8_MouseLeave(object sender, EventArgs e)
        {
            LB_info.Text = @"";
        }
        private void BT_OpenMFolder_Click(object sender, EventArgs e)
        {
            Process.Start("explorer.exe", Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"\.minecraft");
        }

       
    }
}
