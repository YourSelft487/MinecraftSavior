﻿namespace $safeprojectname$
{
    partial class Main_Form
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_Form));
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.BT_reduce = new System.Windows.Forms.Button();
            this.BT_close = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.LB_info = new System.Windows.Forms.Label();
            this.BT_Save = new System.Windows.Forms.Button();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.BW_save_Saves = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.BW_save_Screenshots = new System.ComponentModel.BackgroundWorker();
            this.BW_save_Mods = new System.ComponentModel.BackgroundWorker();
            this.BW_save_Backups = new System.ComponentModel.BackgroundWorker();
            this.BW_save_Resourcepacks = new System.ComponentModel.BackgroundWorker();
            this.BW_save_Shaderpacks = new System.ComponentModel.BackgroundWorker();
            this.BW_save_Versions = new System.ComponentModel.BackgroundWorker();
            this.BT_OpenMFolder = new System.Windows.Forms.Button();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.BackColor = System.Drawing.Color.Sienna;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(14, 32);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(56, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Saves";
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.MouseLeave += new System.EventHandler(this.checkBox1_MouseLeave);
            this.checkBox1.MouseHover += new System.EventHandler(this.checkBox1_MouseHover);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OliveDrab;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.BT_reduce);
            this.panel1.Controls.Add(this.BT_close);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(350, 29);
            this.panel1.TabIndex = 1;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Minecraft Savior";
            this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label1_MouseDown);
            // 
            // BT_reduce
            // 
            this.BT_reduce.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BT_reduce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BT_reduce.Location = new System.Drawing.Point(295, 3);
            this.BT_reduce.Name = "BT_reduce";
            this.BT_reduce.Size = new System.Drawing.Size(23, 23);
            this.BT_reduce.TabIndex = 3;
            this.BT_reduce.Text = "_";
            this.BT_reduce.UseVisualStyleBackColor = true;
            this.BT_reduce.Click += new System.EventHandler(this.BT_reduce_Click);
            // 
            // BT_close
            // 
            this.BT_close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BT_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BT_close.Location = new System.Drawing.Point(324, 3);
            this.BT_close.Name = "BT_close";
            this.BT_close.Size = new System.Drawing.Size(23, 23);
            this.BT_close.TabIndex = 2;
            this.BT_close.Text = "X";
            this.BT_close.UseVisualStyleBackColor = true;
            this.BT_close.Click += new System.EventHandler(this.BT_close_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.BackColor = System.Drawing.Color.Sienna;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(14, 69);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(85, 17);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "Screenshots";
            this.checkBox2.UseVisualStyleBackColor = false;
            this.checkBox2.MouseLeave += new System.EventHandler(this.checkBox2_MouseLeave);
            this.checkBox2.MouseHover += new System.EventHandler(this.checkBox2_MouseHover);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.BackColor = System.Drawing.Color.Sienna;
            this.checkBox3.Location = new System.Drawing.Point(14, 106);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(52, 17);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "Mods";
            this.checkBox3.UseVisualStyleBackColor = false;
            this.checkBox3.MouseLeave += new System.EventHandler(this.checkBox3_MouseLeave);
            this.checkBox3.MouseHover += new System.EventHandler(this.checkBox3_MouseHover);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.BackColor = System.Drawing.Color.Sienna;
            this.checkBox4.Location = new System.Drawing.Point(14, 143);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(68, 17);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.Text = "Backups";
            this.checkBox4.UseVisualStyleBackColor = false;
            this.checkBox4.MouseLeave += new System.EventHandler(this.checkBox4_MouseLeave);
            this.checkBox4.MouseHover += new System.EventHandler(this.checkBox4_MouseHover);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.BackColor = System.Drawing.Color.Sienna;
            this.checkBox5.Checked = true;
            this.checkBox5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox5.Location = new System.Drawing.Point(14, 180);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(101, 17);
            this.checkBox5.TabIndex = 5;
            this.checkBox5.Text = "Resourcepacks";
            this.checkBox5.UseVisualStyleBackColor = false;
            this.checkBox5.MouseLeave += new System.EventHandler(this.checkBox5_MouseLeave);
            this.checkBox5.MouseHover += new System.EventHandler(this.checkBox5_MouseHover);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.BackColor = System.Drawing.Color.Sienna;
            this.checkBox6.Location = new System.Drawing.Point(14, 217);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(89, 17);
            this.checkBox6.TabIndex = 6;
            this.checkBox6.Text = "Shaderpacks";
            this.checkBox6.UseVisualStyleBackColor = false;
            this.checkBox6.MouseHover += new System.EventHandler(this.checkBox6_MouseHover);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.BackColor = System.Drawing.Color.Sienna;
            this.checkBox7.Location = new System.Drawing.Point(14, 254);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(66, 17);
            this.checkBox7.TabIndex = 7;
            this.checkBox7.Text = "Versions";
            this.checkBox7.UseVisualStyleBackColor = false;
            this.checkBox7.MouseLeave += new System.EventHandler(this.checkBox7_MouseLeave);
            this.checkBox7.MouseHover += new System.EventHandler(this.checkBox7_MouseHover);
            // 
            // LB_info
            // 
            this.LB_info.AutoSize = true;
            this.LB_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_info.Location = new System.Drawing.Point(2, 313);
            this.LB_info.Name = "LB_info";
            this.LB_info.Size = new System.Drawing.Size(259, 30);
            this.LB_info.TabIndex = 8;
            this.LB_info.Text = "This folder contains all the Singleplayer words.\r\nYou wouldn\'t delete this, aren\'" +
    "t you ?\r\n";
            // 
            // BT_Save
            // 
            this.BT_Save.BackColor = System.Drawing.Color.OliveDrab;
            this.BT_Save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BT_Save.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_Save.Location = new System.Drawing.Point(256, 248);
            this.BT_Save.Name = "BT_Save";
            this.BT_Save.Size = new System.Drawing.Size(88, 40);
            this.BT_Save.TabIndex = 9;
            this.BT_Save.Text = "Save";
            this.BT_Save.UseVisualStyleBackColor = false;
            this.BT_Save.Click += new System.EventHandler(this.button1_Click);
            // 
            // progressBar1
            // 
            this.progressBar1.ForeColor = System.Drawing.Color.OliveDrab;
            this.progressBar1.Location = new System.Drawing.Point(-1, 325);
            this.progressBar1.Maximum = 0;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(351, 25);
            this.progressBar1.TabIndex = 10;
            this.progressBar1.Visible = false;
            // 
            // BW_save_Saves
            // 
            this.BW_save_Saves.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Saves_DoWork);
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // BW_save_Screenshots
            // 
            this.BW_save_Screenshots.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Screenshots_DoWork);
            // 
            // BW_save_Mods
            // 
            this.BW_save_Mods.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Mods_DoWork);
            // 
            // BW_save_Backups
            // 
            this.BW_save_Backups.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Backups_DoWork);
            // 
            // BW_save_Resourcepacks
            // 
            this.BW_save_Resourcepacks.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Resourcepacks_DoWork);
            // 
            // BW_save_Shaderpacks
            // 
            this.BW_save_Shaderpacks.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Shaderpacks_DoWork);
            // 
            // BW_save_Versions
            // 
            this.BW_save_Versions.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BW_save_Versions_DoWork);
            // 
            // BT_OpenMFolder
            // 
            this.BT_OpenMFolder.BackColor = System.Drawing.Color.OliveDrab;
            this.BT_OpenMFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BT_OpenMFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BT_OpenMFolder.Location = new System.Drawing.Point(162, 248);
            this.BT_OpenMFolder.Name = "BT_OpenMFolder";
            this.BT_OpenMFolder.Size = new System.Drawing.Size(88, 40);
            this.BT_OpenMFolder.TabIndex = 11;
            this.BT_OpenMFolder.Text = "Open minecraft \r\nfolder";
            this.BT_OpenMFolder.UseVisualStyleBackColor = false;
            this.BT_OpenMFolder.Click += new System.EventHandler(this.BT_OpenMFolder_Click);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.BackColor = System.Drawing.Color.Sienna;
            this.checkBox8.Location = new System.Drawing.Point(14, 291);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(106, 17);
            this.checkBox8.TabIndex = 12;
            this.checkBox8.Text = "Whole .minecraft";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.MouseLeave += new System.EventHandler(this.checkBox8_MouseLeave);
            this.checkBox8.MouseHover += new System.EventHandler(this.checkBox8_MouseHover);
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Sienna;
            this.ClientSize = new System.Drawing.Size(350, 350);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.BT_OpenMFolder);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.BT_Save);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.LB_info);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(350, 350);
            this.MinimumSize = new System.Drawing.Size(350, 350);
            this.Name = "Main_Form";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Red;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BT_reduce;
        private System.Windows.Forms.Button BT_close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.Label LB_info;
        private System.Windows.Forms.Button BT_Save;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.ComponentModel.BackgroundWorker BW_save_Saves;
        private System.Windows.Forms.Timer timer1;
        private System.ComponentModel.BackgroundWorker BW_save_Screenshots;
        private System.ComponentModel.BackgroundWorker BW_save_Mods;
        private System.ComponentModel.BackgroundWorker BW_save_Backups;
        private System.ComponentModel.BackgroundWorker BW_save_Resourcepacks;
        private System.ComponentModel.BackgroundWorker BW_save_Shaderpacks;
        private System.ComponentModel.BackgroundWorker BW_save_Versions;
        private System.Windows.Forms.Button BT_OpenMFolder;
        private System.Windows.Forms.CheckBox checkBox8;
    }
}

